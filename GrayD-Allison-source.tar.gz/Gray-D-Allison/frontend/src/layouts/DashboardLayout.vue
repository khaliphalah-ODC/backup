<script setup lang="ts">
import { useRoute } from 'vue-router';
import AlumniShell from '@/components/AlumniShell.vue';
import { useAuth } from '@/stores/auth';
const { user } = useAuth();
import DashboardSidebar from '@/components/DashboardSidebar.vue';
import DashboardTopbar from '@/components/DashboardTopbar.vue';
const route = useRoute();
</script>
<template><AlumniShell v-if="user?.role === 'ALUMNI'"><slot/></AlumniShell><div v-else class="dashboard-ui min-h-screen" :class="route.path === '/admin' ? 'bg-[#f8fafc]' : 'bg-background'"><DashboardSidebar/><div class="lg:ml-sidebar-width"><DashboardTopbar v-if="!['/requests/new', '/admin/alumni'].includes(route.path)"/><main id="main-content" tabindex="-1"><slot/></main></div></div></template>
