<script setup lang="ts">
import { computed, onMounted, onUnmounted, reactive, ref } from 'vue';
import axios from 'axios';
import DashboardLayout from '@/layouts/DashboardLayout.vue';
import ApiAlert from '@/components/ApiAlert.vue';
import { uploadImage } from '@/api/image-upload';
import { useMediaSettings } from '@/composables/useMediaSettings';
import { useAuth } from '@/stores/auth';
import { api, errorMessage } from '@/api/client';
import type { AlumniProfile, ApiResponse } from '@/types/api';
const form = reactive({ fullName: '', graduationYear: '' as number | '', occupation: '', location: '', phone: '', bio: '' });
const photo = ref<string | null>(null), imageVersion = ref(0), profileReady = ref(false);
const { media, mediaError, refreshMedia } = useMediaSettings();
const { refresh, user } = useAuth();
const photoInput = ref<HTMLInputElement | null>(null), photoBusy = ref(false), photoPreview = ref('');
onUnmounted(() => { if (photoPreview.value) URL.revokeObjectURL(photoPreview.value); });
const tab = ref('personal'), preview = ref(false), original = ref<AlumniProfile | null>(null);
const completion = computed(() => { const values = [form.fullName, form.graduationYear, form.occupation, form.location, form.phone, form.bio, photo.value]; return Math.round(values.filter(Boolean).length / values.length * 100); });
function discard() { if (original.value) fill(original.value); notice.value = 'Unsaved changes discarded.'; }
function navigateTabs(event: KeyboardEvent, index: number) {
  let next: number;
  if (event.key === 'ArrowRight') next = (index + 1) % tabs.length;
  else if (event.key === 'ArrowLeft') next = (index + tabs.length - 1) % tabs.length;
  else if (event.key === 'Home') next = 0;
  else if (event.key === 'End') next = tabs.length - 1;
  else return;
  event.preventDefault(); tab.value = tabs[next]![0]!;
  document.getElementById(`tab-${tab.value}`)?.focus();
}
const tabs = [['personal', 'person', 'Personal & Contact Info'], ['academic', 'school', 'Academic Records'], ['career', 'work', 'Bio & Career'], ['security', 'lock_reset', 'Security & Password'], ['privacy', 'shield_person', 'Directory Privacy']];
function photoMetadata(profile: AlumniProfile) { photo.value = profile.profileImage; imageVersion.value = profile.imageVersion; profileReady.value = true; }
function choosePhoto() { if (!photoBusy.value && !busy.value) photoInput.value?.click(); }
async function selectPhoto(event: Event) {
  const input = event.target as HTMLInputElement;
  const file = input.files?.[0];
  input.value = '';
  if (!file) return;
  error.value = ''; notice.value = '';
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
    error.value = 'Choose a JPEG, PNG or WebP image.';
    return;
  }
  photoBusy.value = true;
  try {
    await refreshMedia();
    if (mediaError.value) { error.value = mediaError.value; return; }
    if (file.size > media.value.maxBytes) {
      error.value = `Choose an image smaller than ${Math.floor(media.value.maxBytes / 1024 / 1024)} MB.`;
      return;
    }
    if (!profileReady.value) { error.value = 'Save your profile before uploading a photo.'; return; }
    if (!media.value.enabled) { error.value = media.value.unavailableReason || 'Photo uploads are currently unavailable.'; return; }
    photoPreview.value = URL.createObjectURL(file);
    await uploadImage<null>('/account/profile-image', file, imageVersion.value);
    const saved = (await api.get<ApiResponse<AlumniProfile>>('/alumni/profile')).data.data;
    photoMetadata(saved);
    // Keep the saved image/version when discarding unsaved text edits later.
    if (original.value) Object.assign(original.value, { profileImage: saved.profileImage, imageVersion: saved.imageVersion });
    await refresh();
    notice.value = 'Profile picture saved.';
  } catch (cause) { error.value = errorMessage(cause); }
  finally {
    if (photoPreview.value) URL.revokeObjectURL(photoPreview.value);
    photoPreview.value = '';
    photoBusy.value = false;
  }
}
const loading = ref(true), busy = ref(false), error = ref(''), notice = ref('');
function fill(profile: AlumniProfile) { original.value = { ...profile }; photoMetadata(profile); Object.assign(form, { fullName: profile.fullName, graduationYear: profile.graduationYear ?? '', occupation: profile.occupation ?? '', location: profile.location ?? '', phone: profile.phone ?? '', bio: profile.bio ?? '' }); }
onMounted(async () => { try { fill((await api.get<ApiResponse<AlumniProfile>>('/alumni/profile')).data.data); } catch (e) { if (!axios.isAxiosError(e) || e.response?.status !== 404) error.value = errorMessage(e); } finally { loading.value = false; } });
async function save() { busy.value = true; error.value = ''; notice.value = ''; try { const response = await api.patch<ApiResponse<AlumniProfile>>('/alumni/profile', { ...form, graduationYear: form.graduationYear === '' ? null : Number(form.graduationYear) }); fill(response.data.data); notice.value = 'Profile saved. Your approved verification record is unchanged.'; } catch (e) { error.value = errorMessage(e); } finally { busy.value = false; } }
</script>
<template><DashboardLayout><section class="alumni-page profile-page"><h1 class="sr-only">My alumni profile</h1><ApiAlert :message="error"/><ApiAlert :message="notice" kind="success"/><p v-if="loading" role="status">Loading profile…</p><template v-else>
<header class="alumni-card profile-identity"><div class="profile-identity-main"><div class="profile-avatar"><img v-if="photoPreview || photo" :src="photoPreview || photo || undefined" alt="Your profile photograph" referrerpolicy="no-referrer"><span v-else class="material-symbols-outlined" aria-hidden="true">person</span><button type="button" aria-label="Update profile photograph" :disabled="photoBusy || busy" :aria-busy="photoBusy" @click="choosePhoto"><span class="material-symbols-outlined" aria-hidden="true">{{ photoBusy ? 'hourglass_top' : 'photo_camera' }}</span></button><input id="profile-photo-file" ref="photoInput" type="file" accept="image/jpeg,image/png,image/webp" aria-label="Choose profile photograph" hidden :disabled="photoBusy || busy" @change="selectPhoto"></div><div class="profile-identity-text"><h2>{{ form.fullName || 'My alumni profile' }} <span class="pill blue">Alumni member</span></h2><p>{{ form.graduationYear ? `Class of ${form.graduationYear}` : 'Graduation year not provided' }}<span v-if="form.occupation"> · {{ form.occupation }}</span></p><div class="profile-readiness"><div><span>▣ Profile Readiness</span><strong>{{ completion }}%</strong></div><progress :value="completion" max="100" aria-label="Profile completion"></progress><small>{{ completion === 100 ? 'Your profile is complete.' : 'Complete your profile to help fellow alumni connect with you.' }}</small></div></div></div><div class="profile-header-actions"><button class="alumni-button" form="alumni-profile-form" :disabled="busy || photoBusy"><span class="material-symbols-outlined" aria-hidden="true">save</span>{{ busy ? 'Saving…' : 'Save Changes' }}</button><button class="alumni-button secondary" @click="preview = !preview"><span class="material-symbols-outlined" aria-hidden="true">visibility</span>{{ preview ? 'Close Preview' : 'Preview Public Profile' }}</button></div></header>
<p v-if="photoBusy" role="status">Uploading your profile picture…</p>
<section v-if="preview" class="alumni-card profile-panel" aria-label="Directory profile preview"><p class="eyebrow">Directory profile preview · Unsaved changes</p><h2>{{ form.fullName }}</h2><p>{{ [form.graduationYear ? `Class of ${form.graduationYear}` : '', form.occupation, form.location].filter(Boolean).join(' · ') }}</p><p class="whitespace-pre-wrap">{{ form.bio || 'No biography added.' }}</p><small>Your email and phone are private and excluded from the directory.</small></section>
<div class="alumni-card profile-tabs" role="tablist" aria-label="Profile sections"><button v-for="([id, icon, label], index) in tabs" :id="`tab-${id}`" :key="id" type="button" role="tab" :aria-selected="tab === id" :tabindex="tab === id ? 0 : -1" @keydown="navigateTabs($event, index)" aria-controls="profile-tab-panel" :class="{ active: tab === id }" @click="tab = id!; preview = false"><span class="material-symbols-outlined" aria-hidden="true">{{ icon }}</span>{{ label }}</button></div>
<form id="alumni-profile-form" @submit.prevent="save"><section id="profile-tab-panel" class="alumni-card profile-panel" role="tabpanel" :aria-labelledby="`tab-${tab}`"><template v-if="tab === 'personal'"><div class="profile-panel-heading"><div><h2>Personal &amp; Contact Information</h2><p>Your alumni registry details and private contact information.</p></div><span class="pill">Confidential</span></div><div class="profile-fields"><label><span>Full Legal Name</span><input id="profile-name" v-model.trim="form.fullName" minlength="2" maxlength="150" required autocomplete="name"><small>Use your full name for the alumni registry.</small></label><label><span>Graduation Year</span><input id="profile-year-personal" v-model.number="form.graduationYear" type="number" min="1900" :max="new Date().getFullYear()"><small>Your graduating class in the alumni registry.</small></label><label><span>Primary Institutional &amp; Personal Email</span><input :value="user?.email" readonly type="email"><small>Manage your email in Account Settings.</small></label><label><span>Phone Number</span><input id="profile-phone" v-model.trim="form.phone" type="tel" minlength="6" maxlength="30" autocomplete="tel"><small>Your phone number is private.</small></label><label class="full-width"><span>Current City / Administrative Region</span><input id="profile-location" v-model.trim="form.location" maxlength="500" autocomplete="address-level2"></label></div></template>
<template v-else-if="tab === 'academic'"><h2>Academic Records</h2><p>Keep your alumni class information up to date.</p><div class="profile-fields"><label><span>Graduation Year</span><input id="profile-year" v-model.number="form.graduationYear" type="number" min="1900" :max="new Date().getFullYear()"></label></div><p>Profile edits do not alter your approved membership application.</p><RouterLink class="text-button" to="/requests">View academic document requests →</RouterLink></template>
<template v-else-if="tab === 'career'"><h2>Bio &amp; Career</h2><p>Share your professional journey with fellow graduates.</p><div class="profile-fields"><label class="full-width"><span>Occupation</span><input id="profile-job" v-model.trim="form.occupation" maxlength="500"></label><label class="full-width"><span>Biography</span><textarea id="profile-bio" v-model.trim="form.bio" rows="6" maxlength="2000"></textarea></label></div></template>
<template v-else-if="tab === 'security'"><h2>Security &amp; Password</h2><p>Manage your password and sign-in details in your account settings.</p><RouterLink to="/account/settings" class="alumni-button">Open Account Settings</RouterLink></template>
<template v-else><h2>Directory Privacy</h2><p>Your name, graduation year, occupation, location, biography, and profile photo are visible to approved, activated alumni and administrators.</p><p>Your email and phone number are excluded from directory responses.</p><RouterLink to="/privacy" class="text-button">Read privacy information →</RouterLink></template></section>
<footer class="alumni-card profile-savebar"><p><span class="material-symbols-outlined" aria-hidden="true">shield</span>Profile edits preserve your approved membership record.</p><button class="alumni-button secondary" type="button" :disabled="busy || photoBusy" @click="discard">Discard Changes</button><button class="alumni-button" :disabled="busy || photoBusy"><span class="material-symbols-outlined" aria-hidden="true">verified</span>{{ busy ? 'Saving…' : 'Save Profile & Settings' }}</button></footer></form>
</template></section></DashboardLayout></template>
