<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useAuth } from '@/stores/auth';
import { api, errorMessage } from '@/api/client';
import type { AlumniProfile, ApiResponse } from '@/types/api';
import '@/styles/alumni.css';
const route = useRoute(), router = useRouter(), { user, logout } = useAuth();
const collapsed = ref(false);
const desktopQuery = window.matchMedia('(min-width: 1024px)');
const desktop = ref(desktopQuery.matches);
function viewportChanged(event: MediaQueryListEvent) { desktop.value = event.matches; open.value = false; }
onMounted(() => desktopQuery.addEventListener('change', viewportChanged));
onUnmounted(() => desktopQuery.removeEventListener('change', viewportChanged));
const open = ref(false), search = ref(''), error = ref(''), profile = ref<AlumniProfile | null>(null);
const links = [
  ['dashboard', 'Dashboard', '/dashboard'], ['contacts', 'Alumni Directory', '/alumni'],
  ['chat', 'Chat / Messages', '/messages'], ['badge', 'My Profile', '/profile'],
  ['tune', 'Account Settings', '/account/settings'], ['pending_actions', 'My Requests', '/requests'],
  ['post_add', 'Submit Request', '/requests/new'], ['auto_stories', 'My Stories', '/stories/mine'],
  ['history_edu', 'Stories & Archive', '/stories'], ['campaign', 'Announcements', '/announcements'], ['event', 'Events', '/events'],
];
onMounted(async () => { try { profile.value = (await api.get<ApiResponse<AlumniProfile>>('/alumni/profile')).data.data; } catch { /* The page owns its data error state. */ } });
async function signOut() { try { await logout(); await router.push('/'); } catch (cause) { error.value = errorMessage(cause); } }
function toggleNavigation() { desktop.value = window.matchMedia('(min-width: 1024px)').matches; if (desktop.value) collapsed.value = !collapsed.value; else open.value = !open.value; }
function find() { void router.push({ path: '/alumni', query: search.value.trim() ? { search: search.value.trim() } : {} }); }
</script>
<template>
<div class="alumni-ui" :class="{ 'navigation-collapsed': collapsed }" @keydown.esc="open = false">
  <aside id="alumni-navigation" class="alumni-sidebar" :class="{ 'is-open': open }">
    <RouterLink to="/dashboard" class="alumni-brand"><span class="material-symbols-outlined brand-shield" aria-hidden="true">shield</span><span><strong>GDA Alumni Portal</strong><small>Ministry of National Defense</small></span></RouterLink>
    <p class="nav-caption">Navigation</p>
    <nav aria-label="Alumni navigation"><RouterLink v-for="[icon, label, to] in links" :key="to" :to="to!" :class="{ active: route.path === to }" @click="open = false"><span class="material-symbols-outlined" aria-hidden="true">{{ icon }}</span>{{ label }}</RouterLink></nav>
    <div class="alumni-sidebar-bottom"><RouterLink to="/help"><span class="material-symbols-outlined" aria-hidden="true">headset_mic</span>Support &amp; Helpdesk</RouterLink><button @click="signOut"><span class="material-symbols-outlined" aria-hidden="true">logout</span>Log out</button><p v-if="error" role="alert">{{ error }}</p></div>
  </aside>
  <button v-if="open" class="alumni-backdrop" aria-label="Close navigation" @click="open = false"></button>
  <div class="alumni-workspace">
    <header class="alumni-topbar">
      <button class="icon-button" aria-label="Toggle navigation" :aria-expanded="desktop ? !collapsed : open" aria-controls="alumni-navigation" @click="toggleNavigation"><span class="material-symbols-outlined" aria-hidden="true">menu_open</span></button>
      <nav class="alumni-breadcrumb" aria-label="Breadcrumb"><RouterLink to="/">Home</RouterLink><span aria-hidden="true">›</span><RouterLink to="/dashboard">GDA IMS</RouterLink></nav>
      <div class="alumni-institution"><span class="material-symbols-outlined" aria-hidden="true">military_tech</span>Ministry of National Defense - Armed Forces Educational System</div>
      <form class="alumni-global-search" role="search" @submit.prevent="find"><span class="material-symbols-outlined" aria-hidden="true">search</span><input v-model="search" aria-label="Search alumni directory" placeholder="Search directory, records…" maxlength="150"></form>
      <RouterLink to="/announcements" class="icon-button" aria-label="Announcements"><span class="material-symbols-outlined" aria-hidden="true">notifications</span></RouterLink>
      <RouterLink to="/messages" class="icon-button" aria-label="Messages"><span class="material-symbols-outlined" aria-hidden="true">mail</span></RouterLink>
      <RouterLink to="/account/settings" class="alumni-user"><img v-if="user?.profileImage" :src="user.profileImage" alt="" referrerpolicy="no-referrer"><span v-else class="material-symbols-outlined user-avatar" aria-hidden="true">person</span><span><strong>{{ profile?.fullName || user?.email }}</strong><small>{{ profile?.graduationYear ? `Class of ${profile.graduationYear}` : 'Alumni member' }}</small></span><span class="material-symbols-outlined" aria-hidden="true">expand_more</span></RouterLink>
    </header>
    <main id="main-content" tabindex="-1"><slot/></main>
  </div>
</div>
</template>
